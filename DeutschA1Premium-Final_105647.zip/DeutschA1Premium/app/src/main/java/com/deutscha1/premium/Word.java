package com.deutscha1.premium;
public class Word {
    public final String german, arabic, example;
    public Word(String g,String a,String e){german=g;arabic=a;example=e;}
}
