package com.deutscha1.premium;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    ArrayList<Word> words=new ArrayList<>();
    SharedPreferences prefs; TextToSpeech tts; LinearLayout root; TextView stats;
    int xp,hearts,learned;
    final int BG=Color.rgb(14,17,23),CARD=Color.rgb(25,29,38),TEXT=Color.WHITE,MUTED=Color.rgb(180,185,195),GREEN=Color.rgb(75,210,130);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("deutsch_a1",MODE_PRIVATE);
        xp=prefs.getInt("xp",0); hearts=prefs.getInt("hearts",5); learned=prefs.getInt("learned",0);
        loadWords();
        tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS)tts.setLanguage(Locale.GERMAN);});
        home();
    }
    void loadWords(){
        try{
            java.io.BufferedReader r=new java.io.BufferedReader(new java.io.InputStreamReader(getAssets().open("words.json"),"UTF-8"));
            StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);
            JSONArray a=new JSONArray(s.toString());
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);words.add(new Word(o.getString("german"),o.getString("arabic"),o.getString("example")));}
        }catch(Exception e){Toast.makeText(this,"Database error",Toast.LENGTH_LONG).show();}
    }
    void setup(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,18,18,12);root.setBackgroundColor(BG);setContentView(root);
        TextView t=txt(title,28);t.setTypeface(null,1);root.addView(t);
        stats=txt("❤️ "+hearts+"    ⭐ XP "+xp+"    📚 "+learned+"/"+words.size(),15);stats.setTextColor(MUTED);root.addView(stats);
    }
    TextView txt(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(TEXT);v.setPadding(4,8,4,8);return v;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setTextColor(TEXT);b.setAllCaps(false);b.setBackgroundColor(CARD);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,6);b.setLayoutParams(p);return b;}
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(20,16,20,16);c.setBackgroundColor(CARD);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,7,0,7);c.setLayoutParams(p);return c;}
    void save(){prefs.edit().putInt("xp",xp).putInt("hearts",hearts).putInt("learned",learned).apply();if(stats!=null)stats.setText("❤️ "+hearts+"    ⭐ XP "+xp+"    📚 "+learned+"/"+words.size());}
    void speak(String s){if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"de");}
    void correct(){xp+=10;save();}
    void wrong(){hearts--;if(hearts<=0){hearts=5;Toast.makeText(this,"تمت إعادة القلوب ❤️",Toast.LENGTH_SHORT).show();}save();}

    void home(){
        setup("Deutsch A1 Premium 🇩🇪");root.addView(txt("تعلم الألمانية A1 بطريقة تفاعلية",18));
        LinearLayout c=card();c.addView(txt("المستوى "+(xp/100+1),21));c.addView(txt("XP: "+xp,17));c.addView(txt("الكلمات المتعلمة: "+learned+" / "+words.size(),17));root.addView(c);
        Button a=btn("📚 Wörter — الكلمات");a.setOnClickListener(v->wordsPage());root.addView(a);
        Button g=btn("📖 Grammatik — القواعد");g.setOnClickListener(v->grammar());root.addView(g);
        Button h=btn("🎧 Hören — الاستماع");h.setOnClickListener(v->listening());root.addView(h);
        Button w=btn("✍️ Schreiben — الكتابة");w.setOnClickListener(v->writing());root.addView(w);
        Button q=btn("🧠 اختبار سريع");q.setOnClickListener(v->quiz());root.addView(q);
    }
    void wordsPage(){
        setup("📚 Wörter");Button back=btn("← الرئيسية");back.setOnClickListener(v->home());root.addView(back);
        final int[] i={Math.min(learned,Math.max(0,words.size()-1))};LinearLayout c=card();root.addView(c);
        Runnable render=()->{c.removeAllViews();Word w=words.get(i[0]);TextView de=txt(w.german,30);de.setTextColor(GREEN);c.addView(de);c.addView(txt(w.arabic,22));c.addView(txt("مثال: "+w.example,16));
            Button s=btn("🔊 اسمع");s.setOnClickListener(v->speak(w.german));c.addView(s);
            Button know=btn("⭐ تعلمت");know.setOnClickListener(v->{learned=Math.max(learned,i[0]+1);xp+=10;save();if(i[0]<words.size()-1)i[0]++;render.run();});c.addView(know);
            Button prev=btn("◀ السابقة");prev.setOnClickListener(v->{if(i[0]>0)i[0]--;render.run();});c.addView(prev);
            Button next=btn("التالية ▶");next.setOnClickListener(v->{if(i[0]<words.size()-1)i[0]++;render.run();});c.addView(next);c.addView(txt("الكلمة "+(i[0]+1)+" / "+words.size(),14));};render.run();
    }
    void grammar(){
        setup("📖 Grammatik");Button b=btn("← الرئيسية");b.setOnClickListener(v->home());root.addView(b);
        addG("sein","ich bin\ndu bist\ner/sie ist\nwir sind\nihr seid\nsie/Sie sind");
        addG("haben","ich habe\ndu hast\ner/sie hat\nwir haben\nihr habt\nsie/Sie haben");
        addG("Artikel","der = مذكر\ndie = مؤنث\ndas = محايد\ndie = جمع");
        addG("Negation","nicht = لا / ليس\nkein = لا يوجد / ليس أي");
        addG("Fragen","Wie heißt du?\nWo wohnst du?\nWas machst du?\nWoher kommst du?");
        addG("Modalverben","können = يستطيع\nmüssen = يجب\nwollen = يريد\ndürfen = يُسمح");
    }
    void addG(String h,String body){LinearLayout c=card();c.addView(txt(h,21));TextView b=txt(body,17);b.setTextColor(MUTED);c.addView(b);root.addView(c);}
    void listening(){
        setup("🎧 Hören");Button b=btn("← الرئيسية");b.setOnClickListener(v->home());root.addView(b);
        Word target=words.get(new Random().nextInt(words.size()));LinearLayout c=card();c.addView(txt("استمع ثم اختر المعنى:",19));
        Button s=btn("🔊 تشغيل");s.setOnClickListener(v->speak(target.german));c.addView(s);
        ArrayList<Word> o=new ArrayList<>();o.add(target);Random r=new Random();while(o.size()<4){Word x=words.get(r.nextInt(words.size()));if(!o.contains(x))o.add(x);}Collections.shuffle(o);
        for(Word x:o){Button q=btn(x.arabic);q.setOnClickListener(v->{if(x==target){correct();Toast.makeText(this,"صحيح 🎉",Toast.LENGTH_SHORT).show();listening();}else{wrong();Toast.makeText(this,"خطأ ❌",Toast.LENGTH_SHORT).show();}});c.addView(q);}root.addView(c);
    }
    void writing(){
        setup("✍️ Schreiben");Button b=btn("← الرئيسية");b.setOnClickListener(v->home());root.addView(b);
        Word target=words.get(new Random().nextInt(words.size()));LinearLayout c=card();c.addView(txt("اكتب الكلمة الألمانية:",19));c.addView(txt(target.arabic,24));
        EditText e=new EditText(this);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setHint("Deutsch");c.addView(e);
        Button check=btn("تحقق");check.setOnClickListener(v->{if(e.getText().toString().trim().equalsIgnoreCase(target.german)){correct();Toast.makeText(this,"ممتاز! +10 XP ⭐",Toast.LENGTH_SHORT).show();writing();}else{wrong();Toast.makeText(this,"الصحيح: "+target.german,Toast.LENGTH_LONG).show();}});c.addView(check);root.addView(c);
    }
    void quiz(){
        setup("🧠 اختبار");Button b=btn("← الرئيسية");b.setOnClickListener(v->home());root.addView(b);
        Word target=words.get(new Random().nextInt(words.size()));LinearLayout c=card();TextView q=txt(target.german,34);q.setTextColor(GREEN);c.addView(q);
        ArrayList<Word> o=new ArrayList<>();o.add(target);Random r=new Random();while(o.size()<4){Word x=words.get(r.nextInt(words.size()));if(!o.contains(x))o.add(x);}Collections.shuffle(o);
        for(Word x:o){Button z=btn(x.arabic);z.setOnClickListener(v->{if(x==target){correct();Toast.makeText(this,"صحيح! +10 XP",Toast.LENGTH_SHORT).show();quiz();}else{wrong();Toast.makeText(this,"خطأ ❌",Toast.LENGTH_SHORT).show();}});c.addView(z);}root.addView(c);
    }
    @Override public void onBackPressed(){home();}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
