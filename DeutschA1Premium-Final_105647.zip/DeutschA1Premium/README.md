# Deutsch A1 Premium

Final Android project for the requested A1 learning app.

Features:
- 1000 unique database records in `app/src/main/assets/words.json`
- Arabic translations
- examples
- German TTS
- Wörter
- Grammatik
- Hören
- Schreiben
- Quiz
- 5 hearts
- XP / levels
- persistent progress
- dark UI
- GitHub Actions build

The database is validated by the workflow before the APK is built.
